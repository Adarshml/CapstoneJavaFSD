export class Requests {
    constructor(public adharid:string,
        public emailid:string,
        public name:string,
        public age:number,
        public address:string){}
}
